    #coding 
    # notes 

import string
import random
import time
from colorama import Fore, Back, Style, init
init(autoreset=True)

    # MAIN MENU
def main_menu():  #defining variable
        while True:
            print(Fore.GREEN + "PYTHON ESCAPE: ESCAPE ROOMS - MAIN MENU\n")
            print(Fore.GREEN + "Hello! I am the room master and welcome to PYTHON ESCAPES: ESCAPE ROOMS\n")
            print(Fore.GREEN + "Choose from 1 one of the 2 rooms to play: ")
            
            print("1. THE PHONE NUMBER - Find the hidden key and escape through the main door | Genre: Mystery | Difficulty: ★★★☆☆ | Success Rate: 70%\n")
            print("2. THE SPACE STATION - Escape your failing ship into the safety pod before it explodes! | Genre: Sci-Fi | Difficulty:★★☆☆☆ | Success Rate: 40%\n")

            choice = input(Fore.LIGHTCYAN_EX + "What room would you like to play?: ")

            if choice in ["1", "the phone number", "thephonenumber"]:
                room1()
            elif choice in ["2", "the space station", "thespacestation"]:
                room2()
            else:
                print("That isn’t a valid choice. Try again.")
                print("\n Loading... Room 1: The Phone Number")
            


def after_room(current_room):
        while True:
            choice = input("\nType 'retry' to replay, press ENTER for next room, or 'menu' for main menu: ").strip().lower()
            print()
            if choice == "retry":
                if current_room == "room1":
                    room1()
                elif current_room == "room2":
                    room2()
                return
            elif choice == "menu":
                main_menu()
                return
            else:  # ENTER or anything else
                if current_room == "room1":
                    room2()
                elif current_room == "room2":
                    #room3()
                    pass
                else:
                    main_menu()
                return
            
    #setup
def room1():
        print("\nLoading... Please wait | Room 1: The Phone Number\n")
        time.sleep(1)

        ready = input(Fore.YELLOW + "Type 'start' when you are ready to begin: ").strip().lower()
        while ready != "start":
            ready = input("Type 'start' to begin: ").strip().lower()

        print(Fore.GREEN + "Welcome to the The Phone Number")
        print(Fore.GREEN + "Genre: Mystery | Difficulty: Medium | Success rate: 65%\n")
        print("You are in a room, and you see a desk, a bed, a bookshelf and a vault.\n")
        print("You must find the hidden key and escape through the main door in 7 minutes.\n")
        print("PLAYER COMMANDS - YOU CAN:")
        
        commands = [
            print(Fore.CYAN + "\nAVAILABLE COMMANDS:"),
            print(Fore.BLUE + "inspect [given objects]"),
            print(Fore.BLUE + "get [obtainable items]"),
            print(Fore.BLUE + "unlock [locked objects]"),
            print(Fore.BLUE+ "inventory [view your obtained items]"),
            print(Fore.BLUE + "help, help2, help3 [clues and hints]"),
        ]
        for command in commands:
            print("-", command)

        start_time = time.time()   
        time_limit = 7 * 60  # 7 minutes

        # tracking
        has_vault_code = False
        vault_opened = False
        cabinet_checked = False
        at_cabinet = False
        inventory = []  # stores items the player collects
        finish = False
        control_checked = False
        log_decoded = False 

        vault_code = str(random.randint(1000, 9999))

        objects = {
            "desk": "A note sits on the lit desk: 'Dreams can hide secrets.'",
            "bed": "Under the pillow, you find a note: 'Chris - Paul needs my number, can you give it to him?'",
            "bookshelf": (
                "Just old dusty books. Some books have words. Another has numbers, so I can contact Paul. \n"
                "Behind them shows symbols -> ☑☑☑☑☒☒☒☒\n"
            ),
            "phonebook": (
                "You open the phonebook and flip to page 291.\n\n"
                "Phoebe Boyd: 5432 1190\n"
                "Peter Acevedo: 7723 8201\n"
                f"Paul McCaughney: {vault_code} 0817\n"
                "Patrick Parrish: 1912 1010"
            ),
            "vault": "A heavy steel vault with a keypad. You’ll need a 4-digit code to open it."
        }

        def show_commands():
            print(Fore.CYAN + "\nAVAILABLE COMMANDS:")
            print(Fore.BLUE + "inspect [given objects]",)
            print(Fore.BLUE + "get [obtainable items]")
            print(Fore.BLUE + "unlock [locked objects]")
            print(Fore.BLUE+ "inventory [view your obtained items]")
            print(Fore.BLUE + "help, help2, help3 [clues and hints]")
            
            print()

        #game loop
        while True:
            elapsed = time.time() - start_time
            remaining = int(time_limit - elapsed)

            if remaining <= 0:
                # was: print("\nTime’s up! The code was {code} and the door remains locked.")
                print(f"\nTime’s up! The code was {vault_code} and the door remains locked.")
                break

            print(Fore.RED + f"\nTime left: {remaining // 60} minutes {remaining % 60} seconds")
            command = input(Fore.LIGHTCYAN_EX + "\nWhat do you want to do?: ").strip().lower()
            print()

            #player cmds
            if command in ["inspect desk"]:
                print(objects["desk"])
            elif command in ["inspect bed"]:
                print(objects["bed"])
                print("Maybe Paul’s name shows up somewhere else in the room.")
                has_vault_code = True

            elif command in ["inspect bookshelf"]:
                print(objects["bookshelf"])
                cabinet_checked = True

            elif command in ["inspect door"]:
                print("The main door is locked tight with a padlock. You will need a key to unlock it.")

            elif command == "get phonebook":
                if not cabinet_checked:
                    print("You don’t see a phonebook here.")

                elif "phonebook" in inventory:
                    print("You already picked up the phonebook.")
                else:
                    print("You pull out the small phonebook and place it in your inventory.")
                    inventory.append("phonebook")

            elif command == "use phonebook":
                if "phonebook" in inventory:
                    print(objects["phonebook"])
                    has_vault_code = True
                else:
                    print("You don’t have the phonebook yet.")

            elif command in ["inspect vault"]:
                if not control_checked:
                    print("You don’t see any vault here.")
                else:
                    print("The vault is built into the wall, secured by a 4-digit keypad.")
                    if not log_decoded:
                        print("A small display shows: 'ENTER CODE' — maybe the terminal can help find it.")
                    elif vault_opened:
                        print("The vault is open. It’s empty now.")
                    else:
                        print("You can try 'unlock vault' if you have the code.")

            elif command == "unlock vault":
                if not has_vault_code:
                    print("You do not have the code yet.")
                elif vault_opened:
                    print("The vault is already open.")
                else:
                    code_input = input("Enter the 4-digit code: ").strip()
                    if code_input == vault_code:
                        print(Fore.YELLOW + "VERIFYING...")
                        time.sleep(1)
                        print("The vault beeps and opens, inside is a small yellow key.")
                        vault_opened = True
                    else:
                        print("Incorrect code.")

            elif command == "get key":
                if vault_opened and "key" not in inventory:
                    print("You pick up the small yellow key. It is now in your inventory.")
                    inventory.append("key")
                elif "key" in inventory:
                    print("You already have the key in your inventory.")
                else:
                    print("There is no key available to take right now.")


            elif command == "inventory":
                if inventory:
                    print("Inventory:", ", ".join(inventory))
                else:
                    print("Your inventory is empty.")

            elif command == "unlock door":
                if "key" in inventory:
                    print("You insert the yellow key into the lock... click! The door opens and you escape Room 2!")
                    finish = True
                    break
                else:
                    print("The door is locked. You need a key to open it.")

            elif command in ["help"]:
                show_commands()
                print(Fore.BLUE + "Try looking at the desk, bookshelf, or bed.")
            elif command in ["help2"]:
                print(Fore.BLUE + "Maybe something in the bookshelf can help you.")
            elif command in ["help3"]:
                print(Fore.BLUE + "Try getting a certain type of book in the bookshelf so you can Pauls number")
            else:
                print("That doesn’t seem to do anything.")

        after_room("room2")

    # ___________________________________________________________________________________________
    # room 2

def room2():
    print("\nLoading... Room 2: The Space Station")
    time.sleep(1)

    ready = input(Fore.YELLOW + "Type 'start' when you are ready to begin: ").strip().lower()
    while ready != "start":
        ready = input("Type 'start' to begin: ").strip().lower()
        time.sleep(1)

    # show a prompt line right after start
    print(Fore.LIGHTCYAN_EX + "\nWhat do you want to do?:\n")

    print(Fore.GREEN + "WELCOME TO THE SPACE STATION\n")
    print(Fore.GREEN + "Genre: Sci-Fi | Difficulty: ??? | Success rate: ???%\n")
    print(Fore.GREEN + "You are a new astronaut sent up on a mission in Station Kepler-5 Space Rocket\n")
    print(Fore.GREEN + "Your station has malfunctioned and is rapidly losing oxygen.\n")
    print(Fore.GREEN + "A power surge knocked out the main systems, the oxygen is draining, and you need to restore power, access the escape pod, and launch before time runs out.\n")
    print(Fore.GREEN + "You step out of the main rocket's cockpit — you can enter the engineering bay, control room, the airlock, the pod, and pod cockpit.\n")
    print(Fore.GREEN + "You must escape in 7 minutes before the core melts.\n")

    # --- state ---
    inventory = []
    notebook = []
    power_restored = False
    log_decoded = False
    airlock_checked = False
    control_checked = False
    drawer_opened = False
    vault_opened = False
    pod_unlocked = False
    finish = False
    start_time = time.time()
    time_limit = 7 * 60
    vault_code = str(random.randint(1000, 9999))

    rooms = {
        "engineering bay": "Tools float beside a dead power control unit. A fuse PANEL sparks occasionally.",
        "airlock": "A dim room with flashing red lights and a locked panel. A box floats near a wall, labeled 'SAFETY KIT'. On the wall you see: 'KEPLER-5 GEARS'.",
        "control room": "You walk into the control room. A long desk holds your computer TERMINAL and a locked DRAWER. Lights buzz. The terminal flickers with system error logs.",
        "pod": "An area with the data computer and a sealed door locked with a digital keypad needing 4-digit numbers.",
        "vault": "Placed on a shelf locked with a 4 digit keypad."
    }

    objects = {
        "panel": "The maintenance panel needs a screwdriver to open.",
        "terminal": "The terminal flickers with garbled system logs. It looks encrypted.",
        "pod_console": "The main console displays syntax errors. You’ll need an access card.",
        "access_card": "A plastic card labeled 'K-005' with a magnetic strip.",
        "safety kit": "You find oxygen tanks, a fuse, and an access card labeled K-005.",
        "decoder": "A box disc - decoder device that can be inserted into computers.",
        "drawer": "A small metal drawer with a simple latch under the desk.",
        "paper": "A small note: 'Power logs — ENGINEERING BAY. Code linked to systems: check the terminal.'",
        "desk": "You look around seeing your monitor; below that you see a small drawer.",
        "vault": "Placed on a shelf, locked with a 4 digit keypad."
    }

    def show_commands():
        print(Fore.CYAN + "\nAVAILABLE COMMANDS:")
        print(Fore.BLUE + "- inspect [objects and rooms]")
        print(Fore.BLUE + "- get [item]")
        print(Fore.BLUE + "- fix [certain objects]")
        print(Fore.BLUE + "- unlock [doors and objects]")
        print(Fore.BLUE + "- inventory [view obtained items]")
        print(Fore.BLUE + "- notebook [write or view notes]")
        print(Fore.BLUE + "- 'launch' the pod as the final escape")
        print(Fore.BLUE + "- help (show this list again)")
        print(Fore.BLUE + "- help2 [for clues or assistance]")
        print(Fore.BLUE + "- pause [pause or exit the game]")

    show_commands()

    # --- main loop ---
    while True:
        elapsed = time.time() - start_time
        remaining = int(time_limit - elapsed)
        if remaining <= 0:
            print(Fore.RED + "\nTime’s up! Oxygen depleted. The station explodes.")
            break

        print(Fore.RED + f"\nTime left: {remaining // 60} minutes {remaining % 60} seconds")
        command = input(Fore.LIGHTCYAN_EX + "What do you want to do?: ").strip().lower()
        print()

        # Pause menu
        if command == "pause":
            print(Fore.YELLOW + "\nGAME PAUSED")
            print("Type 'resume' to get back to game.\n")
            paused_time = time.time()
            while True:
                resume_input = input(Fore.LIGHTCYAN_EX + "GAME PAUSED > ").strip().lower()
                if resume_input == "resume":
                    pause_duration = time.time() - paused_time
                    start_time += pause_duration
                    print(Fore.GREEN + "\n--- GAME RESUMED ---\n")
                    break
                elif resume_input == "exit":
                    print("Exiting game...")
                    return
                else:
                    print("Type 'resume' to continue or 'exit' to quit.")

        elif command == "notebook":
            print(Fore.YELLOW + "\n📝 Your Notebook")
            print("Type any note below, or press ENTER to view your notes.")
            note = input(">> ").strip()
            if note:
                notebook.append(note)
                print(Fore.GREEN + "Note added to notebook ✅")
            else:
                if notebook:
                    print(Fore.CYAN + "Your notes:")
                    for i, line in enumerate(notebook, 1):
                        print(f"{i}. {line}")
                else:
                    print("Your notebook is empty.")

        elif command == "help":
            show_commands()

        elif command == "help2":
            print("Try inspecting some of the rooms.")

        elif command == "help3":
            print("Try decoding the letters and numbers for the drawer pin.")

        # Room interactions
        elif command in ["inspect engineering bay"]:
            print(rooms["engineering bay"])
            print("You see a SCREWDRIVER and a fuse PANEL, but a tool and a fuse are missing.")

        elif command == "get screwdriver":
            if "screwdriver" not in inventory:
                inventory.append("screwdriver")
                print("You grab the screwdriver and place it in your inventory.")
            else:
                print("You already have the screwdriver.")

        elif command in ["inspect airlock"]:
            print(rooms["airlock"])
            airlock_checked = True

        elif command in ["inspect control room"]:
            print(rooms["control room"])
            control_checked = True
            print("Underneath the desk, a small DRAWER, and a locked VAULT is built into the wall nearby.")

        elif command in ["inspect desk"]:
            print(objects["desk"])

        elif command in ["inspect paper"]:
            print(objects["paper"])

        # Drawer (no auto-decoder now)
        elif command in ["inspect drawer"]:
            print(objects["drawer"])
            if drawer_opened:
                print("It’s open. You can see a small note and an access card inside.")  # wording preserved

        elif command == "open drawer":
            if not control_checked:
                print("You don’t see any drawer here.")
            else:
                if not drawer_opened:
                    print("You open the drawer — inside is a DECODER device.")
                    drawer_opened = True
                else:
                    print("The drawer is already open.")

        elif command == "get decoder":
            if drawer_opened and "decoder" not in inventory:
                inventory.append("decoder")
                print("You take the decoder and place it in your inventory.")
            elif "decoder" in inventory:
                print("You already have the decoder.")
            else:
                print("You don’t see any decoder here.")

        # Terminal
        elif command in ["inspect terminal"]:
            if not log_decoded:
                print("The terminal flickers with garbled system logs and static lines.")
                print("It seems to be encrypted. Maybe something could help decode it.")
                if "decoder" in inventory:
                    use_dec = input("You have a decoder device. Use it? (yes/no): ").strip().lower()
                    if use_dec == "yes":
                        print("You insert the decoder into the terminal...")
                        time.sleep(1.5)
                        print(Fore.YELLOW + "The screen stabilizes and displays:")
                        print(Fore.CYAN + f"'LOG DECRYPTED — VAULT SYSTEM CODE: {vault_code}'")
                        log_decoded = True
                    else:
                        print("You step back from the terminal.")
                else:
                    print("You need a decoder to read this properly.")
            else:
                print(f"The decrypted log still reads: 'VAULT SYSTEM CODE: {vault_code}'.")

        # Vault
        elif command in ["inspect vault"]:
            print(objects["vault"])

        elif command == "unlock vault":
            code = input("Enter the 4-digit code: ").strip()
            if code == vault_code:
                print(Fore.GREEN + "The vault clicks open, you find a key inside.")
                vault_opened = True
            else:
                print("The keypad beeps. Wrong code.")

        elif command == "get key":
            if vault_opened and "key" not in inventory:
                inventory.append("key")
                print("You pick up the small yellow key. It is now in your inventory.")
            elif "key" in inventory:
                print("You already have the key in your inventory.")
            else:
                print("There is no key available to take right now.")

        # Safety kit / fuse / access card
        elif command in ["inspect safety kit"]:
            print(objects["safety kit"])

        elif command in ["get fuse"]:
            if not airlock_checked:
                print("There is no fuse here — maybe check the airlock first.")
            elif "fuse" in inventory:
                print("You already have the fuse.")
            else:
                inventory.append("fuse")
                print("You take the fuse and add it to your inventory.")

        elif command == "get access card":
            if airlock_checked and "access card" not in inventory:
                print("You find the access card labeled 'K-005' inside the safety kit and add it to your inventory.")
                inventory.append("access card")
            elif "access card" in inventory:
                print("You already have the access card.")
            else:
                print("You don’t see any access card here.")

        # Power panel
        elif command in ["inspect panel"]:
            print(objects["panel"])
            if not power_restored:
                print("You see a broken fuse box with an empty slot — you need something and a fuse to fix this.")
            else:
                print("The panel is running steadily with the power on.")

        elif command in ["fix panel"]:
            if power_restored:
                print("The system is already running.")
            elif "screwdriver" in inventory and "fuse" in inventory:
                print("You place the fuse in and use the screwdriver to tighten the screws.")
                print("You hear whirrings, the lights suddenly flicker on.")
                print("You look over at the console: 'SYSTEM-K-005 POWER RESTORED'")
                power_restored = True
            elif "screwdriver" in inventory:
                print("You can open the panel, but a fuse is still needed.")
            elif "fuse" in inventory:
                print("You have the fuse, but you still need a tool to open the panel.")
            else:
                print("You need a tool and a fuse to fix the panel.")

        # Pod
        elif command in ["inspect pod"]:
            if not pod_unlocked:
                print("You see the pod cockpit door but it’s locked with the access code, and the POD TERMINAL is logged out. You need an access card and a key to unlock and enter the pod cockpit.")
            else:
                print("The door is now unlocked. Inside, the pod console computer waits for verification...")
                time.sleep(1)
                print("You notice a slot labeled 'ACCESS CARD - K-005 REQUIRED.'")

        elif command == "unlock pod":
            if not power_restored:
                print("There’s no power to the pod systems. Fix the panel first.")
            elif "key" in inventory and "access card" in inventory:
                print("You swipe the access card... the console lights up.")
                time.sleep(1)
                print(Fore.GREEN + "You insert the yellow key... the pod door opens! You climb inside.")
                print("Engines ignite — you escape just as the station explodes!")
                finish = True
                break
            elif "key" in inventory and "access card" not in inventory:
                print("You have the key, but the pod requires an access card to activate the console.")
            elif "access card" in inventory and "key" not in inventory:
                print("You have the access card, but the pod is still locked — maybe there’s a key somewhere.")
            else:
                print("The pod is locked tight. You need both a key and an access card.")

        elif command in ["inspect pod console"]:
            print(objects["pod_console"])
            if "access card" in inventory and power_restored:
                print("A slot flashes green — you can insert your access card here to activate the pod.")
            elif not power_restored:
                print("The console is dead. You need to restore power first.")
            else:
                print("A small slot next to the screen is labeled 'ACCESS CARD REQUIRED.'")

        elif command in ["use access card"]:
            if not power_restored:
                print("There’s no power. The console doesn’t respond.")
            elif not pod_unlocked:
                print("You can’t use that yet — the pod door is still locked.")
            elif "access card" not in inventory:
                print("You don’t have an access card.")
            else:
                print("You swipe the access card on the console...")
                time.sleep(1)
                print(Fore.GREEN + "The console beeps: 'ACCESS GRANTED — POD SYSTEM ONLINE.'")
                print("You can now launch the pod when ready.")
                objects["pod_console"] = "The pod console glows with life — systems ready for launch."

        elif command in ["use pod", "enter pod", "launch pod"]:
            if not power_restored:
                print("The pod has no power and is inaccessible.")
            elif "access card" not in inventory:
                print("You need an access card to activate the console before launching.")
            elif not pod_unlocked:
                print("The pod door is still locked. You’ll need to unlock it first.")
            else:
                print(Fore.GREEN + "LAUNCHING...")
                time.sleep(1)
                print(Fore.GREEN + "Preparing K-005 Engines...")
                time.sleep(1)
                print("Engines ignite — you launch from Station Kepler-5 just as it explodes behind you!")
                print("LEVEL COMPLETE")
                finish = True
                break

        # Inventory
        elif command == "inventory":
            if inventory:
                print("Inventory:", ", ".join(inventory))
            else:
                print("Your inventory is empty.")

        else:
            print("That doesn't do anything.")

    after_room("end")
    
main_menu()